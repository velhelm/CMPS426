Open up the Main scene in the Scenes directory. Click on the buttons on the right of the screen to go to each
different scene. In seek scene, press F to toggle idle, seek and pursuit and T to toggle targets. For the interpose
state, ASDW and the arrow keys will move the player characters. For other steering, left click to add waypoints.

For Boids, prepare yourself for the most action packed event of the holiday season.
Must have sound on&Occulus Rift.